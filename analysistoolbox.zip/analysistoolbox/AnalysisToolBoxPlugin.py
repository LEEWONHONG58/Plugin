from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from .AnalysisToolBox import AnalysisToolbox
from . import resources  # resources.py를 import

class AnalysisToolboxPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        # QAction 생성
        self.action = QAction(QIcon(":/plugins/analysistoolbox/icon/LSDS.png"), "Analysis Toolbox", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        # 플러그인 메뉴에 추가
        self.iface.addPluginToMenu("Analysis Toolbox", self.action)

        # 도구 모음에 추가
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # 플러그인 메뉴에서 제거
        self.iface.removePluginMenu("Analysis Toolbox", self.action)

        # 도구 모음에서 제거
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dialog = AnalysisToolbox()
        self.dialog.show()
