# __init__.py

def classFactory(iface):
    from .AnalysisToolBoxPlugin import AnalysisToolboxPlugin
    return AnalysisToolboxPlugin(iface)

