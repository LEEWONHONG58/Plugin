from PyQt5.QtCore import QStringListModel, Qt, QVariant
from PyQt5.QtGui import QIntValidator, QDoubleValidator
from qgis.core import QgsVectorLayer, QgsFeature, QgsField, QgsProject
from PyQt5.QtWidgets import QDialog, QCheckBox, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QListView, QGridLayout, QPushButton, QMessageBox, QGroupBox, QLineEdit, QSizePolicy, QTableWidget, QTableWidgetItem
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from sklearn.metrics import mean_squared_error
from scipy import stats
from sklearn.linear_model import Lasso
from sklearn.preprocessing import StandardScaler
import numpy as np
import statsmodels.api as sm

class LassoDialog(QDialog):
    """
    class Lasso_Regression
    Author : WonHong Lee
    LAB : LSDS
    Date : 2024.08.13 ~ 2024.08.20
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.indepCount = 0
        self.ratioPercent = 0
        self.tuning = None
        self.regulationValue = 0
        self.init_ui()
        self.setup_connections()
        self.reset_ui()

    def reset_ui(self):
        self.populateShapefiles()
        self.dependentBox.clear()
        self.dependentBox.addItem("", None)
        self.fieldModel.setStringList([])
        self.independentModel.setStringList([])

        self.ratioLine.clear()
        self.regulationLine.clear()
        
        self.ratioBox.setChecked(False)
        self.regulationBox.setChecked(False)
        self.tuningBox.setChecked(False)
        
        self.regulationLine.setEnabled(True)
        self.ratioLine.setEnabled(True)

        self.indepCount = 0
        self.ratioPercent = 0
        self.regulationValue = 0
        self.tuning = None

    # connect train ratio text
    def onratioTextChanged(self, text):
        try:
            value = int(text)
            if value < 0 or value > 100:
                QMessageBox.warning(self, 'Error', '올바른 숫자를 기입하세요(0 ~ 100).')
                self.ratioLine.clear()
                self.ratioPercent = 0
            else:
                self.ratioPercent = value
        except ValueError:
            if text:
                QMessageBox.warning(self, 'Error', '숫자를 입력하세요.')
                self.ratioLine.clear()
                self.ratioPercent = 0
                
    # connect train ratio box    
    def onratioChecked(self, state):
        if state == Qt.Checked:
            self.ratioLine.setEnabled(False)
            self.ratioPercent = 70
            self.ratioLine.setText(f"{self.ratioPercent}")
        else:
            self.ratioLine.setEnabled(True)
            self.ratioLine.clear()
            self.ratioPercent = 0
            
    # connect lambda Value box
    def onregulationChecked(self, state):
        if state == Qt.Checked:
            self.regulationLine.setEnabled(False)
            self.regulationValue = -2.00
            self.regulationLine.setText(f"{self.regulationValue}")
        else:
            self.regulationLine.setEnabled(True)
            self.regulationLine.clear()
            self.regulationValue = 0
    
    # connect lambda Value text
    def onregulationTextChanged(self, text):
        try:
            if text == '-' or text == '':
                return
            value = float(text)
            if value < -4.00 or value > 0.00:
                QMessageBox.warning(self, 'Error', '올바른 수를 기입하세요(-4 ~ 0).')
                self.regulationLine.clear()
                self.regulationValue = 0
            else:
                self.regulationValue = 10**value
        except ValueError:
            if text and self.tuning == False:
                QMessageBox.warning(self, 'Error', '수를 입력하세요.')
                self.regulationLine.clear()
                self.regulationValue = 0

    # connect Tuning box
    def ontuningChecked(self, state):
        if state == Qt.Checked:
            self.tuning = True
            self.regulationLine.setText(" ")
            self.regulationBox.setChecked(False)
            self.regulationBox.setEnabled(False)
            self.regulationLine.setEnabled(False)
        else:
            self.tuning = False
            self.regulationLine.setEnabled(True)
            self.regulationBox.setEnabled(True)
    
    # connect function
    def setup_connections(self):
        self.targetBox.currentTextChanged.connect(self.updateFieldsAndDependentBox)
        self.inButton.clicked.connect(self.addIndependentVariable)
        self.outButton.clicked.connect(self.removeIndependentValueable)
        self.ratioBox.stateChanged.connect(self.onratioChecked)
        self.ratioLine.textChanged.connect(self.onratioTextChanged)
        self.regulationBox.stateChanged.connect(self.onregulationChecked)
        self.regulationLine.textChanged.connect(self.onregulationTextChanged)
        self.tuningBox.stateChanged.connect(self.ontuningChecked)
        self.runButton.clicked.connect(self.runLassoRegression)
        self.cancelButton.clicked.connect(self.close)        
    
    # UI    
    def init_ui(self):
        self.mainLayout = QVBoxLayout()
        self.selectLayout = QVBoxLayout()
        self.targetLabel = QLabel("Select a Target Layer:")
        self.selectLayout.addWidget(self.targetLabel)
        self.targetBox = QComboBox()
        self.selectLayout.addWidget(self.targetBox)

        self.dependentLabel = QLabel("Dependent Variable:")
        self.selectLayout.addWidget(self.dependentLabel)
        self.dependentBox = QComboBox()
        self.selectLayout.addWidget(self.dependentBox)
        
        self.ratioLayout = QHBoxLayout()
        self.ratioLabel = QLabel("Ratio of Train Set (%):")
        self.ratioLayout.addWidget(self.ratioLabel)
        self.ratioLine = QLineEdit()
        self.ratioLine.setPlaceholderText("0 ~ 100 (%)")
        self.ratioLine.setValidator(QIntValidator(0, 100, self))
        self.ratioLine.setAlignment(Qt.AlignCenter)
        self.ratioLayout.addWidget(self.ratioLine, alignment=Qt.AlignLeft)
        self.ratioLine.setFixedWidth(80)
        self.ratioDefault = QLabel("Default")
        self.ratioLayout.addWidget(self.ratioDefault)
        self.ratioDefault.setFixedWidth(50)
        self.ratioBox = QCheckBox()
        self.ratioLayout.addWidget(self.ratioBox)
        self.selectLayout.addLayout(self.ratioLayout)
                
        self.mainLayout.addLayout(self.selectLayout)
        
        self.fieldLayout = QGridLayout()

        self.fieldLabel = QLabel("Fields")
        self.fieldLayout.addWidget(self.fieldLabel, 0, 0, alignment=Qt.AlignCenter)
        self.fieldView = QListView()
        self.fieldView.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.fieldModel = QStringListModel()
        self.fieldView.setModel(self.fieldModel)
        self.fieldLayout.addWidget(self.fieldView, 1, 0, 2, 1)

        self.inButton = QPushButton(">")
        self.inButton.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        self.inButton.setFixedSize(60, 20)
        self.fieldLayout.addWidget(self.inButton, 1, 1, alignment=Qt.AlignCenter)
        self.outButton = QPushButton("<")
        self.outButton.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        self.outButton.setFixedSize(60, 20)
        self.fieldLayout.addWidget(self.outButton, 2, 1, alignment=Qt.AlignCenter)

        self.independentLabel = QLabel("Independent Variables")
        self.fieldLayout.addWidget(self.independentLabel, 0, 2, alignment=Qt.AlignCenter)
        self.independentView = QListView()
        self.independentView.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.independentModel = QStringListModel()
        self.independentView.setModel(self.independentModel)
        self.fieldLayout.addWidget(self.independentView, 1, 2, 2, 1)
        
        self.mainLayout.addLayout(self.fieldLayout)
        
        self.hyperparameterGroupBox = QGroupBox("Set HyperParameter")
        self.additionGrid = QGridLayout()
        
        self.regulationLabel = QLabel("Regulation(log scale):")
        self.additionGrid.addWidget(self.regulationLabel, 0, 0, 1, 2, alignment=Qt.AlignLeft)
        self.regulationLine = QLineEdit()
        self.regulationLine.setPlaceholderText("-4 ~ 0")
        self.regulationLine.setValidator(QDoubleValidator(-4, 0, 2, self))
        self.regulationLine.setAlignment(Qt.AlignCenter)
        self.additionGrid.addWidget(self.regulationLine, 0, 2, alignment=Qt.AlignLeft)
        self.regulationLine.setFixedWidth(60)
        self.regulationDefault = QLabel("Default")
        self.additionGrid.addWidget(self.regulationDefault, 0, 3, alignment=Qt.AlignLeft)
        self.regulationDefault.setFixedWidth(50)
        self.regulationBox = QCheckBox()
        self.additionGrid.addWidget(self.regulationBox, 0, 4, alignment=Qt.AlignLeft)
        
        self.tuningLabel = QLabel("Hyper Parameter Tuning")
        self.additionGrid.addWidget(self.tuningLabel, 1, 0, 1, 2, alignment=Qt.AlignLeft)
        self.tuningBox = QCheckBox()
        self.additionGrid.addWidget(self.tuningBox, 1, 2, alignment=Qt.AlignLeft)
        
        self.hyperparameterGroupBox.setLayout(self.additionGrid)
        self.mainLayout.addWidget(self.hyperparameterGroupBox)

        self.buttonLayout = QHBoxLayout()
        self.runButton = QPushButton("Run")
        self.cancelButton = QPushButton("Cancel")
        self.buttonLayout.addStretch()
        self.buttonLayout.addWidget(self.runButton)
        self.buttonLayout.addWidget(self.cancelButton)
        self.runButton.setFixedSize(self.cancelButton.sizeHint())

        self.mainLayout.addLayout(self.buttonLayout)

        self.setLayout(self.mainLayout)
        self.setGeometry(300, 200, 350, 425)
        
    def populateShapefiles(self):
        self.targetBox.clear()
        layers = QgsProject.instance().mapLayers().values()
        valid_layers = [layer for layer in layers if isinstance(layer, QgsVectorLayer) and layer.dataProvider().storageType() == 'ESRI Shapefile']
        if valid_layers:
            self.targetBox.addItem("", None)
            for layer in valid_layers:
                self.targetBox.addItem(layer.name(), layer)
        else:
            self.targetBox.addItem("No shapefile layers available", None)
            
    def updateFieldsAndDependentBox(self):
        self.dependentBox.clear()
        self.dependentBox.addItem("", None)
        self.fieldModel.setStringList([])
        self.independentModel.setStringList([])
        current_layer = self.targetBox.currentData()
        if current_layer:
            numeric_fields = []
            for field in current_layer.fields():
                all_values_numeric = True
                for feature in current_layer.getFeatures():
                    value = feature[field.name()]
                    if not isinstance(value, (int, float, type(None))):
                        all_values_numeric = False
                        break

                if all_values_numeric:
                    numeric_fields.append(field.name())

            if numeric_fields:
                self.fieldModel.setStringList(numeric_fields)
                self.dependentBox.addItems(numeric_fields)
            else:
                self.fieldModel.setStringList(["No numeric fields"])
                self.dependentBox.addItem("No numeric fields available")

    def addIndependentVariable(self):
        selected_indexes = self.fieldView.selectedIndexes()
        if selected_indexes:
            selected_field = selected_indexes[0].data()
            field_list = self.fieldModel.stringList()
            independent_fields = self.independentModel.stringList()
            if selected_field not in independent_fields:
                independent_fields.append(selected_field)
                field_list.remove(selected_field)
                self.independentModel.setStringList(independent_fields)
                self.fieldModel.setStringList(field_list)
                self.indepCount += 1
    
    def removeIndependentValueable(self):
        selected_indexes = self.independentView.selectedIndexes()
        if selected_indexes:
            selected_field = selected_indexes[0].data()
            field_list = self.fieldModel.stringList()
            independent_fields = self.independentModel.stringList()
            if selected_field not in field_list:
                field_list.append(selected_field)
                independent_fields.remove(selected_field)
                self.fieldModel.setStringList(field_list)
                self.independentModel.setStringList(independent_fields)
                self.indepCount -= 1

    def hyperparameterTuning(self, X_train, y_train):

        param_grid = {'alpha': np.logspace(-4, 0, 100)}
        
        lasso = Lasso(random_state=42)
        grid_search = GridSearchCV(lasso, param_grid, cv=5, scoring='neg_mean_squared_error', n_jobs=1, verbose=3)
        grid_search.fit(X_train, y_train)
        return grid_search.best_params_

    def runLassoRegression(self):
        try:
            current_layer = self.targetBox.currentData()
            if current_layer is None:
                QMessageBox.warning(self, "Error", "Target Layer를 선택하세요")
                return
            dependent_field = self.dependentBox.currentText()
            independent_fields = self.independentModel.stringList()
            if not dependent_field or not independent_fields:
                QMessageBox.warning(self, "Error", "독립변수, 종속변수가 올바르게 선택되었는지 확인하세요")
                return

            y = []
            X = []
            for feature in current_layer.getFeatures():
                y_value = feature[dependent_field]
                if y_value is None:
                    continue
                y.append(y_value)
                x_row = []
                for field in independent_fields:
                    x_value = feature[field]
                    if x_value is None:
                        x_value = 0
                    x_row.append(x_value)
                X.append(x_row)
            
            if not y or not X:
                QMessageBox.warning(self, "Error", "독립변수, 종속변수 데이터가 올바른 형식이 아닙니다.")
                return

            X = np.array(X)
            y = np.array(y)
            
            if len(X.shape) == 1:
                X = X.reshape(-1, 1)
            
            test_size = 1 - (self.ratioPercent / 100)
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)

            # 스케일링 (Lasso는 변수의 크기에 민감하므로 표준화가 중요)
            scaler = StandardScaler()
            X_train = scaler.fit_transform(X_train)
            X_test = scaler.transform(X_test)
            
            if self.tuning == True:
                best_params = self.hyperparameterTuning(X_train, y_train)
                self.regulationValue = best_params['alpha']
            else:
                self.regulationValue = self.regulationValue

            X_with_intercept = sm.add_constant(X)

            model = sm.OLS(y, X_with_intercept).fit()

            # 회귀 분석 결과 추출
            intercept = model.params[0]
            coefficients = model.params[1:]
            r_squared = model.rsquared
            adj_r_squared = model.rsquared_adj
            std = model.bse[1:]
            t_stats = model.tvalues[1:]
            p_values = model.pvalues[1:]
            
            # Intercept 통계량
            intercept_std = model.bse[0]
            intercept_t_stat = model.tvalues[0]
            intercept_p_value = model.pvalues[0]
            intercept_stats = [intercept, intercept_std, intercept_t_stat, intercept_p_value]
            
            self.showResults(independent_fields, intercept_stats, coefficients, r_squared, adj_r_squared, std, t_stats, p_values, self.regulationValue)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
            return

    def showResults(self, independent_fields, intercept_stats, coefficients, r_squared, adj_r_squared, std, t_stats, p_values, regulationValue):
        self.resultDialog = LassoRegressResults(independent_fields, intercept_stats, coefficients, r_squared, adj_r_squared, std, t_stats, p_values, regulationValue)
        self.resultDialog.show()
        self.resultDialog.raise_()
        self.resultDialog.activateWindow()
    
    def show(self):
        self.reset_ui()
        super().show()
        self.raise_()
        self.activateWindow()
    
class LassoRegressResults(QDialog):
    """
    RegressResults class
    Author : WH Lee
    LAB : LSDS
    Date : 2024.07.23 ~ 2024.07.31
    """
    def __init__(self, independent_fields, intercept_stats, coefficients, r_squared, adj_r_squared, t_stats, p_values, regulationValue):
        super(LassoRegressResults, self).__init__()
        self.independent_fields = independent_fields
        self.intercept_stats = intercept_stats
        self.coefficients = coefficients
        self.t_stats = t_stats
        self.p_values = p_values
        self.r_squared = r_squared
        self.adj_r_squared = adj_r_squared
        self.regulationValue = regulationValue
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        # R-squared and Adjusted R-squared labels
        stats_layout = QHBoxLayout()
        r2_label = QLabel(f"R²: {self.r_squared:.3f}")
        adj_r2_label = QLabel(f"Adjusted R²: {self.adj_r_squared:.3f}")
        regulationLabel = QLabel(f"alpha: {self.regulationValue:.2f}")
        stats_layout.addWidget(r2_label)
        stats_layout.addWidget(adj_r2_label)
        stats_layout.addWidget(regulationLabel)
        layout.addLayout(stats_layout)
        # Table for the regression results
        self.table = QTableWidget(self)
        self.table.setColumnCount(5)
        self.table.setRowCount(len(self.coefficients) + 1)
        self.table.setHorizontalHeaderLabels(["Variable", "Coefficients", "t stats", "P Value"])
        
        intercept_item = QTableWidgetItem("intercept")
        intercept_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        self.table.setItem(0, 0, intercept_item)

        intercept_value_item = QTableWidgetItem(f"{self.intercept_stats[0]:.4f}")
        intercept_value_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        self.table.setItem(0, 1, intercept_value_item)

        intercept_t_stat_item = QTableWidgetItem(f"{self.intercept_stats[2]:.2f}")
        intercept_t_stat_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        self.table.setItem(0, 2, intercept_t_stat_item)

        intercept_p_value_item = QTableWidgetItem(f"{self.intercept_stats[3]:.4f}" if self.intercept_stats[3] > 0.0001 else "<.0001")
        intercept_p_value_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        self.table.setItem(0, 3, intercept_p_value_item)

        vif_empty_item = QTableWidgetItem("")
        vif_empty_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        self.table.setItem(0, 5, vif_empty_item)

        for i, coef in enumerate(self.coefficients):
            field_item = QTableWidgetItem(self.independent_fields[i])
            field_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            self.table.setItem(i + 1, 0, field_item)

            coef_item = QTableWidgetItem(f"{self.coefficients[i]:.4f}")
            coef_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            self.table.setItem(i + 1, 1, coef_item)

            t_stat_item = QTableWidgetItem(f"{self.t_stats[i]:.2f}")
            t_stat_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            self.table.setItem(i + 1, 2, t_stat_item)

            p_value_item = QTableWidgetItem(f"{self.p_values[i]:.4f}" if self.p_values[i] > 0.0001 else "<.0001")
            p_value_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            self.table.setItem(i + 1, 3, p_value_item)

            vif_item = QTableWidgetItem(f"{self.vif[i]:.4f}")
            vif_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            self.table.setItem(i + 1, 4, vif_item)
        
        layout.addWidget(self.table)
        self.setLayout(layout)
        self.setWindowTitle("Lasso Regression Results")
        self.setGeometry(660, 225, 675, 300)