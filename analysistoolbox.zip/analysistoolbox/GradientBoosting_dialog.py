from qgis.core import QgsVectorLayer, QgsFeature, QgsField, QgsProject
from PyQt5.QtCore import QStringListModel, QVariant, Qt, QTimer
from PyQt5.QtGui import QIntValidator, QDoubleValidator
from PyQt5.QtWidgets import QDialog, QCheckBox, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QListView, QGridLayout, QPushButton, QMessageBox, QGroupBox, QLineEdit, QSizePolicy, QTableWidget, QTableWidgetItem, QProgressDialog, QApplication
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_squared_error

class GradientBoostingDialog(QDialog):
    """
    GradientBoosting class
    Author : WonHong Lee
    LAB : LSDS
    Date : 2024.08.10 ~ 
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.indepCount = 0
        self.ratioPercent = 0
        self.LearningPercent = 0.00
        self.tuning = None
        self.init_ui()
        self.setup_connections()
        self.reset_ui()
            
    def reset_ui(self):
        self.populateShapefiles()
        self.dependentBox.clear()
        self.dependentBox.addItem("", None)
        self.fieldModel.setStringList([])
        self.independentModel.setStringList([])
        
        self.ratioLine.clear()
        self.LearningLine.clear()
        
        self.ratioBox.setChecked(False)
        self.tuningBox.setChecked(False)
        
        self.ratioLine.setEnabled(True)
        self.LearningLine.setEnabled(True)
        
        self.indepCount = 0
        self.ratioPercent = 0
        self.LearningPercent = 0.00
        self.tuning = None
    
    def setup_connections(self):
        self.targetBox.currentTextChanged.connect(self.updateFieldsAndDependentBox)
        self.ratioLine.textChanged.connect(self.onratioTextChanged)
        self.ratioBox.stateChanged.connect(self.onratioChecked)
        self.inButton.clicked.connect(self.addIndependentVariable)
        self.outButton.clicked.connect(self.removeIndependentValueable)
        self.LearningLine.textChanged.connect(self.onLearningTextChanged)
        self.tuningBox.stateChanged.connect(self.ontuningChecked)
        self.runButton.clicked.connect(self.runGradientBoosting)
        self.cancelButton.clicked.connect(self.close)
        
    def onratioTextChanged(self, text):
        try:
            value = int(text)
            if value < 0 or value > 100:
                QMessageBox.warning(self, 'Error', '올바른 숫자를 기입하세요(0 ~ 100).')
                self.ratioLine.clear()
                self.ratioPercent = 0
            else:
                self.ratioPercent = value
        except ValueError:
            if text:
                QMessageBox.warning(self, 'Error', '숫자를 입력하세요.')
                self.ratioLine.clear()
                self.ratioPercent = 0
        
    def onratioChecked(self, state):
        if state == Qt.Checked:
            self.ratioLine.setEnabled(False)
            self.ratioPercent = 70
            self.ratioLine.setText(f"{self.ratioPercent}")
        else:
            self.ratioLine.setEnabled(True)
            self.ratioLine.clear()
            self.ratioPercent = 0

    def onLearningTextChanged(self, text):
        try:
            value = float(text)
            if value < 0.01 or value > 0.1:
                QMessageBox.warning(self, 'Error', '올바른 학습률을 기입하세요(0.01 ~ 0.1).')
                self.LearningLine.clear()
                self.LearningPercent = 0.00
            else:
                self.LearningPercent = value
        except ValueError:
            if text and self.tuning == False:
                QMessageBox.warning(self, 'Error', '비율을 입력하세요.')
                self.LearningLine.clear()
                self.LearningPercent = 0.00

    def ontuningChecked(self, state):
        if state == Qt.Checked:
            self.tuning = True
            self.LearningLine.setText(" ")
            self.LearningLine.setEnabled(False)
        else:
            self.tuning = False
            self.LearningLine.setEnabled(True)
    
    def init_ui(self):
        # Create Layout, Widgets
        self.mainLayout = QVBoxLayout()

        # Select Layer Layout
        self.selectLayout = QVBoxLayout()
        self.targetLabel = QLabel("Select a Target Layer:")
        self.selectLayout.addWidget(self.targetLabel)
        self.targetBox = QComboBox()
        self.selectLayout.addWidget(self.targetBox)

        self.dependentLabel = QLabel("Dependent Variable:")
        self.selectLayout.addWidget(self.dependentLabel)
        self.dependentBox = QComboBox()
        self.selectLayout.addWidget(self.dependentBox)

        self.mainLayout.addLayout(self.selectLayout)
        
        self.ratioLayout = QHBoxLayout()
        self.ratioLabel = QLabel("Ratio of Train Set (%):")
        self.ratioLayout.addWidget(self.ratioLabel)
        self.ratioLine = QLineEdit()
        self.ratioLine.setPlaceholderText("0 ~ 100 (%)")
        self.ratioLine.setValidator(QIntValidator(0, 100, self))
        self.ratioLine.setAlignment(Qt.AlignCenter)
        self.ratioLayout.addWidget(self.ratioLine, alignment=Qt.AlignLeft)
        self.ratioLine.setFixedWidth(80)
        self.ratioDefault = QLabel("Default")
        self.ratioDefault.setAlignment(Qt.AlignCenter)
        self.ratioLayout.addWidget(self.ratioDefault)
        self.ratioDefault.setFixedWidth(50)
        self.ratioBox = QCheckBox()
        self.ratioLayout.addWidget(self.ratioBox)
        self.selectLayout.addLayout(self.ratioLayout)
                
        self.mainLayout.addLayout(self.selectLayout)

        self.fieldLayout = QGridLayout()

        self.fieldLabel = QLabel("Fields")
        self.fieldLayout.addWidget(self.fieldLabel, 0, 0, alignment=Qt.AlignCenter)
        self.fieldView = QListView()
        self.fieldView.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.fieldModel = QStringListModel()
        self.fieldView.setModel(self.fieldModel)
        self.fieldLayout.addWidget(self.fieldView, 1, 0, 2, 1)

        self.inButton = QPushButton(">")
        self.inButton.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        self.inButton.setFixedSize(50, 20)
        self.fieldLayout.addWidget(self.inButton, 1, 1, alignment=Qt.AlignCenter)
        self.outButton = QPushButton("<")
        self.outButton.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        self.outButton.setFixedSize(50, 20)
        self.fieldLayout.addWidget(self.outButton, 2, 1, alignment=Qt.AlignCenter)

        self.independentLabel = QLabel("Independent Variables")
        self.fieldLayout.addWidget(self.independentLabel, 0, 2, alignment=Qt.AlignCenter)
        self.independentView = QListView()
        self.independentView.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.independentModel = QStringListModel()
        self.independentView.setModel(self.independentModel)
        self.fieldLayout.addWidget(self.independentView, 1, 2, 2, 1)
        
        self.mainLayout.addLayout(self.fieldLayout)

        self.hyperparameterGroupBox = QGroupBox("Set HyperParameter")
        self.additionGrid = QGridLayout()
        
        self.LearningLabel = QLabel("Learning rate")
        self.additionGrid.addWidget(self.LearningLabel, 0, 0, alignment=Qt.AlignLeft)
        self.LearningLine = QLineEdit()
        self.LearningLine.setPlaceholderText("0.01 ~ 0.10")
        self.LearningLine.setValidator(QDoubleValidator(0.01, 0.1, 2, self))
        self.LearningLine.setAlignment(Qt.AlignCenter)
        self.additionGrid.addWidget(self.LearningLine, 0, 1, alignment=Qt.AlignCenter)
        self.LearningLine.setFixedWidth(70)
        
        self.tuningLabel = QLabel("Hyper Parameter Tuning")
        self.additionGrid.addWidget(self.tuningLabel, 0, 2, 1, 2, alignment=Qt.AlignLeft)
        self.tuningBox = QCheckBox()
        self.additionGrid.addWidget(self.tuningBox, 0, 4, alignment=Qt.AlignLeft)

        self.hyperparameterGroupBox.setLayout(self.additionGrid)
        self.mainLayout.addWidget(self.hyperparameterGroupBox)
        
        self.buttonLayout = QHBoxLayout()
        self.runButton = QPushButton("Run")
        self.cancelButton = QPushButton("Cancel")
        self.buttonLayout.addStretch()
        self.buttonLayout.addWidget(self.runButton)
        self.buttonLayout.addWidget(self.cancelButton)
        self.runButton.setFixedSize(self.cancelButton.sizeHint())

        self.mainLayout.addLayout(self.buttonLayout)

        self.setLayout(self.mainLayout)
        self.setGeometry(300, 200, 325, 425)


        
    def populateShapefiles(self):
        self.targetBox.clear()  # ComboBox 초기화
        layers = QgsProject.instance().mapLayers().values()
        # 벡터 레이어 중에서 Shapefile 형식만 필터링
        valid_layers = [layer for layer in layers if isinstance(layer, QgsVectorLayer) and layer.dataProvider().storageType() == 'ESRI Shapefile']
        if valid_layers:
            self.targetBox.addItem("", None)  # 첫 선택지 추가
            for layer in valid_layers:
                self.targetBox.addItem(layer.name(), layer)
        else:
            self.targetBox.addItem("No shapefile layers available", None)

    def updateFieldsAndDependentBox(self):
        self.dependentBox.clear()
        self.dependentBox.addItem("", None)
        self.fieldModel.setStringList([])
        self.independentModel.setStringList([])
        current_layer = self.targetBox.currentData()  # 현재 선택된 레이어 데이터 가져오기
        if current_layer:
            numeric_fields = []
            for field in current_layer.fields():
                # 모든 피처를 검사하여 해당 필드가 숫자형 데이터만 포함하는지 확인
                all_values_numeric = True
                for feature in current_layer.getFeatures():
                    value = feature[field.name()]
                    if not isinstance(value, (int, float, type(None))):  # None은 결측치 허용
                        all_values_numeric = False
                        break

                if all_values_numeric:  # 모든 값이 숫자형인 필드만 추가
                    numeric_fields.append(field.name())

            if numeric_fields:
                self.fieldModel.setStringList(numeric_fields)
                self.dependentBox.addItems(numeric_fields)
            else:
                self.fieldModel.setStringList(["No numeric fields"])
                self.dependentBox.addItem("No numeric fields available")

    def addIndependentVariable(self):
        selected_indexes = self.fieldView.selectedIndexes()
        if selected_indexes:
            selected_field = selected_indexes[0].data()
            field_list = self.fieldModel.stringList()
            independent_fields = self.independentModel.stringList()
            if selected_field not in independent_fields:
                independent_fields.append(selected_field)
                field_list.remove(selected_field)
                self.independentModel.setStringList(independent_fields)
                self.fieldModel.setStringList(field_list)

    def removeIndependentValueable(self):
        selected_indexes = self.independentView.selectedIndexes()
        if selected_indexes:
            selected_field = selected_indexes[0].data()
            field_list = self.fieldModel.stringList()
            independent_fields = self.independentModel.stringList()
            if selected_field not in field_list:
                field_list.append(selected_field)
                independent_fields.remove(selected_field)
                self.fieldModel.setStringList(field_list)
                self.independentModel.setStringList(independent_fields)
    
    def hyperparameterTuning(self, X_train, y_train, n, progress_dialog):
        success = False
        n_estimators = [i for i in range(100, 1001, 100)]
        
        while not success:
            param_grid = {
                'n_estimators': n_estimators,
                'learning_rate': [0.1],
                'max_depth': [5],
                'min_samples_split': [2],
                'min_samples_leaf': [3],
                'subsample': [0.8],
                'max_features': [k + 1 for k in range(n)]
            }
            progress_dialog.setValue(20)
            gbm = GradientBoostingRegressor(random_state=42)
            grid_search = GridSearchCV(estimator=gbm, param_grid=param_grid, cv=3, n_jobs=1, verbose=2)
            grid_search.fit(X_train, y_train)
            
            best_n_estimators = grid_search.best_params_['n_estimators']
            
            if 100 < best_n_estimators and best_n_estimators < 1000:
                success = True
                progress_dialog.setValue(80)
                return grid_search.best_params_
            
            elif best_n_estimators == 100:
                progress_dialog.setValue(50)
                n_estimators = [i for i in range(1, 101, 1)]
                param_grid = {
                    'n_estimators': n_estimators,
                    'learning_rate': [0.1],
                    'max_depth': [5],
                    'min_samples_split': [2],
                    'min_samples_leaf': [3],
                    'subsample': [0.8],
                    'max_features': [k + 1 for k in range(n)]
                }
                gbm = GradientBoostingRegressor(random_state=42)
                grid_search = GridSearchCV(estimator=gbm, param_grid=param_grid, cv=3, n_jobs=1, verbose=2)
                grid_search.fit(X_train, y_train)
                best_n_estimators = grid_search.best_params_['n_estimators']
                if best_n_estimators <= 100:
                    progress_dialog.setValue(80)
                    success = True
                    return grid_search.best_params_

            elif best_n_estimators == 1000 or best_n_estimators > 1000:
                progress_dialog.setValue(50)
                if best_n_estimators >= max(n_estimators):
                    lower_bound = max(n_estimators)
                    upper_bound = lower_bound + 1000
                    n_estimators = [i for i in range(lower_bound, upper_bound, 50)]
                    param_grid = {
                        'n_estimators': n_estimators,
                        'learning_rate': [0.1],
                        'max_depth': [5],
                        'min_samples_split': [2],
                        'min_samples_leaf': [3],
                        'subsample': [0.8],
                        'max_features': [k + 1 for k in range(n)]
                    }
                    gbm = GradientBoostingRegressor(random_state=42)
                    grid_search = GridSearchCV(estimator=gbm, param_grid=param_grid, cv=3, n_jobs=1, verbose=2)
                    grid_search.fit(X_train, y_train)
                    best_n_estimators = grid_search.best_params_['n_estimators']
                    if best_n_estimators < upper_bound:
                        progress_dialog.setValue(70)
                        lower_bound_fine = best_n_estimators - 49 if best_n_estimators - 49 > lower_bound else lower_bound
                        upper_bound_fine = best_n_estimators + 49 if best_n_estimators + 49 < upper_bound else upper_bound - 1
                        n_estimators_fine = [i for i in range(lower_bound_fine, upper_bound_fine + 1)]
                        param_grid_fine = {
                            'n_estimators': n_estimators_fine,
                            'learning_rate': [0.1],
                            'max_depth': [5],
                            'min_samples_split': [2],
                            'min_samples_leaf': [3],
                            'subsample': [0.8],
                            'max_features': [k + 1 for k in range(n)]
                        }
                        gbm = GradientBoostingRegressor(random_state=42)
                        grid_search_fine = GridSearchCV(estimator=gbm, param_grid=param_grid_fine, cv=3, n_jobs=1, verbose=2)
                        grid_search_fine.fit(X_train, y_train)
                        progress_dialog.setValue(90)
                        success = True
                        return grid_search_fine.best_params_
                else:
                    progress_dialog.setValue(90)
                    success = True
                    return grid_search.best_params_
    
    def runGradientBoosting(self):
        try:
            current_layer = self.targetBox.currentData()
            if current_layer is None:
                QMessageBox.warning(self, "Error", "Target Layer를 선택하세요")
                return
            dependent_field = self.dependentBox.currentText()
            independent_fields = self.independentModel.stringList()
            if not dependent_field or not independent_fields:
                QMessageBox.warning(self, "Error", "독립변수, 종속변수가 올바르게 선택되었는지 확인하세요")
                return
            if not self.ratioLine.text() and not self.ratioBox.isChecked():
                QMessageBox.warning(self, "Error", "Train 비율을 입력하세요")
                return

            X = []
            y = []
            feature_ids = []
            for feature in current_layer.getFeatures():
                y_value = feature[dependent_field]
                if y_value is None:
                    continue
                y.append(y_value)
                x_row = []
                for field in independent_fields:
                    x_value = feature[field]
                    if x_value is None:
                        x_value = 0
                    x_row.append(x_value)
                X.append(x_row)
                feature_ids.append(feature.id())
            
            if not X or not y:
                    QMessageBox.warning(self, "Error", "독립변수, 종속변수 데이터가 올바른 형식이 아닙니다.")
                    return
            
            X = np.array(X)
            y = np.array(y)
            
            test_size = 1 - (self.ratioPercent / 100)
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)
            
            if self.tuning == True:
                try:
                    # 로딩 창 생성
                    progress_dialog = QProgressDialog("분석 중...", None, 0, 100, self)
                    progress_dialog.setWindowTitle("Gradient Boosting     ")
                    progress_dialog.setWindowModality(Qt.WindowModal)
                    progress_dialog.setCancelButton(None)
                    progress_dialog.setValue(0)
                    progress_dialog.show()

                    progress_dialog.setWindowModality(Qt.WindowModal)
                    progress_dialog.show()

                    # 이벤트 큐 처리
                    QApplication.processEvents()

                    n = len(independent_fields)
                    best_params = self.hyperparameterTuning(X_train, y_train, n, progress_dialog)
                    
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
                    
                finally:
                    # 로딩 창 닫기
                    progress_dialog.setValue(100)
                    QTimer.singleShot(2000, lambda: progress_dialog.close)
                
                self.treeValue = best_params['n_estimators']
                self.mtryValue = best_params['max_features']
                self.LearningPercent = best_params['learning_rate']
                max_depth = best_params['max_depth']
                min_samples_split = best_params['min_samples_split']
                min_samples_leaf = best_params['min_samples_leaf']
                subsample = best_params['subsample']
            else:
                n = len(independent_fields)
                best_params = self.hyperparameterTuning(X_train, y_train, n)
                max_depth = 10
                min_samples_split = 2
                min_samples_leaf = 1
                subsample = 0.9
                self.LearningPercent = float(self.LearningLine.text())

            model = GradientBoostingRegressor(
                n_estimators=self.treeValue, max_features=self.mtryValue, learning_rate=self.LearningPercent,
                max_depth=max_depth, min_samples_split=min_samples_split, min_samples_leaf=min_samples_leaf,
                subsample=subsample, random_state=42)
            model.fit(X_train, y_train)
            
            y_prediction = model.predict(X_test)
            y_prediction_all = model.predict(X)
            mse = mean_squared_error(y_test, y_prediction)
            rmse = np.sqrt(mse)
            std = np.std(y_test - y_prediction)
            
            labels = [self.treeValue, self.LearningPercent]
            self.showResults(labels, dependent_field, rmse, std)
            ### 속성 테이블에 예측값 추가
            if not current_layer.isValid():
                QMessageBox.critical(self, "Error", "This Layer is not valid")
                return

            new_field_name = f"{dependent_field}_GB"
            current_layer.startEditing() 
            field_index = current_layer.fields().indexOf(new_field_name)
            if field_index != -1:
                success = current_layer.dataProvider().deleteAttributes([field_index])
                if not success:
                    QMessageBox.warning(self, "Error", f"Failed to delete existing field {new_field_name}")
                current_layer.updateFields()

            new_field = QgsField(new_field_name, QVariant.Double)
            current_layer.dataProvider().addAttributes([new_field])
            current_layer.updateFields()
            field_index = current_layer.fields().indexOf(new_field_name)

            # 매핑된 feature_id와 prediction을 사용하여 속성값을 업데이트
            feature_prediction_map = dict(zip(feature_ids, y_prediction_all))
            for feature in current_layer.getFeatures():
                feature_id = feature.id()
                prediction = feature_prediction_map.get(feature_id)
                if prediction is not None:
                    # QVariant.Double은 float과 호환o, numpy와 호환x
                    success = current_layer.changeAttributeValue(feature_id, field_index, float(prediction))
                    if not success:
                        QMessageBox.warning(self, "Error", f"Failed to update feature({feature_id}) with prediction {prediction}")
            current_layer.commitChanges()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
            return
        
    def showResults(self, labels, dependent_field, rmse, std):
        self.resultDialog = GBMResults(labels, dependent_field, rmse, std)
        self.resultDialog.show()
        self.resultDialog.raise_()
        self.resultDialog.activateWindow()
    
    def show(self):
        self.reset_ui()
        super().show()
        self.raise_()
        self.activateWindow()
    
class GBMResults(QDialog):
    def __init__(self, labels, dependent_field, rmse, std):
        super(GBMResults, self).__init__()
        self.labels = labels
        self.dependent_field = dependent_field
        self.rmse = rmse
        self.std = std
        self.init_ui()
        self.raise_()

    def init_ui(self):
        layout = QVBoxLayout(self)
        
        results = QHBoxLayout(self)
        tree_label = QLabel(f"Number of Trees: {self.labels[0]}")
        results.addWidget(tree_label)
        learning_label = QLabel(f"Learning rate: {self.labels[1]:.2f}")
        results.addWidget(learning_label)
        
        layout.addLayout(results)
        
        rmse_table = QTableWidget(self)
        rmse_table.setRowCount(1)
        rmse_table.setColumnCount(3)
        rmse_table.setHorizontalHeaderLabels(["Variable","RMSE","Std"])
        
        dependent_field_item = QTableWidgetItem(self.dependent_field)
        dependent_field_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        rmse_table.setItem(0, 0, dependent_field_item)

        rmse_value_item = QTableWidgetItem(f"{self.rmse:.4f}")
        rmse_value_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        rmse_table.setItem(0, 1, rmse_value_item)

        std_value_item = QTableWidgetItem(f"{self.std:.4f}")
        std_value_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        rmse_table.setItem(0, 2, std_value_item)
        layout.addWidget(rmse_table)
        
        self.setLayout(layout)
        self.setWindowTitle("Gradient Boosting Results")
        self.setGeometry(700, 200, 350, 150)