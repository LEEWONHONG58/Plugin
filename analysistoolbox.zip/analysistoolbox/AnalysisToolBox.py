from PyQt5.QtWidgets import QShortcut
from PyQt5.QtGui import QKeySequence
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QDesktopWidget, QShortcut
from .LinearRegression_dialog import LinearRegressionDialog
from .randomforest_dialog import RandomForestDialog
from .GradientBoosting_dialog import GradientBoostingDialog
from .Lasso_dialog import LassoDialog


class AnalysisToolbox(QDialog):  # QDialog로 되돌리기
    def __init__(self):
        super().__init__()
        self.dialogs = []
        self.init_ui()

        # ESC 키 연결
        self.shortcut = QShortcut(QKeySequence(Qt.Key_Escape), self)
        self.shortcut.activated.connect(self.close)  # self.reject 대신 self.close 사용

    def init_ui(self):
        layout = QVBoxLayout(self)

        label = QLabel("Select an analysis tool:")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

        linreg_button = QPushButton("Linear Regression")
        linreg_button.clicked.connect(self.run_linear_regression)
        layout.addWidget(linreg_button)

        random_forest_button = QPushButton("Random Forest")
        random_forest_button.clicked.connect(self.run_random_forest)
        layout.addWidget(random_forest_button)

        gradient_boosting_button = QPushButton("Gradient Boosting")
        gradient_boosting_button.clicked.connect(self.run_gradient_boosting)
        layout.addWidget(gradient_boosting_button)

        lasso_button = QPushButton("Lasso Regression")
        lasso_button.clicked.connect(self.run_lasso_regression)
        layout.addWidget(lasso_button)
        
        self.resize(300, 150)
        self.center()

    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def run_linear_regression(self):
        self.open_dialog(LinearRegressionDialog)

    def run_random_forest(self):
        self.open_dialog(RandomForestDialog)

    def run_gradient_boosting(self):
        self.open_dialog(GradientBoostingDialog)

    def run_lasso_regression(self):
        self.open_dialog(LassoDialog)

    def open_dialog(self, DialogClass):
        dialog = DialogClass(self)
        dialog.setAttribute(Qt.WA_DeleteOnClose)
        self.dialogs.append(dialog)
        dialog.show()

        dialog.raise_()
        dialog.activateWindow()

        dialog.finished.connect(lambda: self.dialogs.remove(dialog))

    def show(self):
        self.setWindowModality(Qt.NonModal)  # 비모달 설정
        super().show()
