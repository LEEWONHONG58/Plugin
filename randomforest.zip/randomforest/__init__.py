from .randomforest import RandomForest

def classFactory(iface):
    return RandomForest(iface)
